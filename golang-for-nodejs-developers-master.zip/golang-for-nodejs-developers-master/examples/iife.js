(function(name) {
  console.log('hello', name)
})('bob')
