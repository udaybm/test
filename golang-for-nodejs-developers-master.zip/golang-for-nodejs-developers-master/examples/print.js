console.log('print to stdout')
console.log('format %s %d', 'example', 1)
console.error('print to stderr')
