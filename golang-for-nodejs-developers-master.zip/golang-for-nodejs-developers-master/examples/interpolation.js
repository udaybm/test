const name = 'bob'
const age = 21
const message = `${name} is ${age} years old`

console.log(message)
