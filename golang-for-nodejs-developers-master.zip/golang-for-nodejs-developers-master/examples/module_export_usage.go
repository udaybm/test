package main

import (
	greeter "github.com/miguelmota/golang-for-nodejs-developers/examples/greeter_go"
)

func main() {
	greeter.Greet("bob")
}
