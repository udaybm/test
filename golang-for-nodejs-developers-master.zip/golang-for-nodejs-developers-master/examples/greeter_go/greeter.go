package greeter

import (
	"fmt"
)

// Greet ...
func Greet(name string) {
	fmt.Printf("hello %s", name)
}
