const moment = require('moment')

const now = moment().unix()
console.log(now)
