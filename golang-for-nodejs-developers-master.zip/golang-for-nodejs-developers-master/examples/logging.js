console.log((new Date()).toISOString(), 'hello world')
