module.exports = {
  greet(name) {
    console.log(`hello ${name}`)
  }
}
