const obj = { key: 'foo', value: 'bar' }

const { key, value } = obj
console.log(key, value)
