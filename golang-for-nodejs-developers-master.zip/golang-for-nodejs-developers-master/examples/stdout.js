process.stdout.write('hello world\n')
