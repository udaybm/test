package main

import "log"

func main() {
	// Package `log` writes to standard error ánd prints the date and time of each logged message
	log.Println("hello world")
}
