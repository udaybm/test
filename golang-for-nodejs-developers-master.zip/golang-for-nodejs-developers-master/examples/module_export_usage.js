const greeter = require('./module_export')

greeter.greet('bob')
