const key = process.env['API_KEY']

console.log(key)
