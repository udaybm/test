// this is a line comment

/*
 this is a block comment
*/
