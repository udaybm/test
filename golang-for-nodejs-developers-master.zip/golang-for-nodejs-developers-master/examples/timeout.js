setTimeout(callback, 1e3)

function callback() {
  console.log('called')
}
