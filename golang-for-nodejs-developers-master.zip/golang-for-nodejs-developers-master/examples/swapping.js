let a = 'foo'
let b = 'bar'

console.log(a, b);

[b, a] = [a, b]

console.log(a, b)
